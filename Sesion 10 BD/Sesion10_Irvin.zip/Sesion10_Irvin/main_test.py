"""
Biblioteca 

"""

import lib.funciones_calcular as fc
import lib.finciones_biblioteca as fb

print(57*'*')
print('\nBienvenido al sistema de control de inventario de libros.\n')
print(57*'*')


while True:
    print('Digite la opcion que desea: ')
    print('1 - Agregar libro al iventario')
    print('2 - Mostrar libros del inventario')
    print('3 - Buscar libros del inventario')
    print('4 - Borrar libro del inventario')
    print('5 - Usar la calculadora')
    print('0 - Salir')
    print(57*'*')

    opcion = int(input('Digite la opcion.'))

    if opcion == 0:
        print('\n Gracias por usar el sistema, feliz dia!')
        break
    elif opcion == 1:
        titulo = input('Ingrese el titulo del libro: ')
        autor = input('Ingrese el nombre del autor del libro: ')
        fecha = input('Ingrese la fecha del libro: ')
        fb.add_book(titulo, autor, fecha)
    elif opcion == 2:
        print('El inventario actual es: \n\n')
        fb.show_book()
    elif opcion == 3:
        busqueda = input('Digite el titulo del libro a buscar: ')
        fb.search_book(busqueda)
    elif opcion == 4:
        eliminar = input('Digite el titulo del libro a eliminar: ')
        fb.del_book(eliminar)
    elif opcion == 5:
        print('Bienvenido a la calculadora\n')

        op= input('Digite la operacion a utilizar\n')
        print('Las funciones son: Sumar, Restar, Multiplicar y Dividir\n')
        a = float(input('Digite el primer numero: '))
        b = float(input('Digite el segundo numero: '))

        if op.lower() == 'Sumar':
            print('La suma es: ',fc.add_function(a,b))
        elif op.lower() == 'Restar':
            print('La resta es: ',fc.sus_function(a,b))
        elif op.lower() == 'Multiplicar':
            print('La multiplicacion es: ',fc.mult_function(a,b))
        elif op.lower() == 'Dividir':
            print('La division es: ',fc.div_function(a,b))
        else:
            print('\nOperacion no encontrada')

        
    else:
        print('\nOpcion invalida, intente de nuevo\n')


#fb.add_book('Silabario', 'Anonimo', 1990)
#fb.add_book('Nacho', 'Anonimo', 1910)
#fb.add_book('Salado', 'Anonimo', 1988)
#fb.add_book('Casas de papel', 'Anonimo', 1999)

#fb.show_book()

#fb.search_book('nacho')
#fb.search_book('pasta')


#fb.del_book('nacho')

#suma = fc.add_function(4, 5)

#print('El resultado es: ', suma)

#resta = fc.sus_function(9, 5)

#print('El resultado es: ', resta)

#multi = fc.mult_function(4, 5)

#print('El resultado es: ', multi)

#div = fc.div_function(10, 5)

#print('El resultado es: ', div)