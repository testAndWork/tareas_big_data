libros = []
def add_book(titulo, autor, fecha):
    libros.append({'Titulo':titulo, 'Autor': autor, 'Fecha':fecha})

def show_book():
    for libro in libros:

        print(f"'Titulo:{libro['Titulo']} Autor: {libro['Autor']} Fecha de publicacion: {libro['Fecha']}")
    
def search_book():
    encontrado = False
    for libro in libros:
        if tituloLibro.lower() in libro['Titulo'].lower():
            print('Libro encontrado con exito! \n')
            print(f"Titulo: {libro['Titulo']} Autor: {libro['Autor']} Fecha de publicacion: {libro['Fecha']}")
            encontrado = True
            break
    if not encontrado:
        print(f'\n El libro "{titulo_libro}" no existe, favor verificar')

def del_book(titulo_libro):
    encontrado = False
    for libro in libros:
        if titulo_libro.lower() in libro['Titulo'].lower():
            print(f'\n Eliminando libro de titulo {titulo_libro}')
            print(f"Titulo: {libro['Titulo']} Autor: {libro['Autor']} Fecha de publicacion: {libro['Fecha']}")
            libros.remove(libro)
            encontrado = True
            break
    if not encontrado:
        print(f'\n El libro "{titulo_libro}" no existe, favor verificar')