def add_function(x, y) :
    return x + y


def mult_function(x, y):
    return x * y
def sus_function(x, y):
    return x - y
def div_function(x, y):
    return (x / y if y != 0 else print('DivByZero'))
